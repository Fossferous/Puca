const s="/assets/rnnoise_simd-BsE3sPy6.wasm";export{s as default};
