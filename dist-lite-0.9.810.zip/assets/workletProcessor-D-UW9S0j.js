const s="/assets/workletProcessor-oeaMQ38w.js";export{s as default};
