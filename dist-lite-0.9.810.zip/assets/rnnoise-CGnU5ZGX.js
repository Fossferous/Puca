const s="/assets/rnnoise-lVVwgm0Y.wasm";export{s as default};
